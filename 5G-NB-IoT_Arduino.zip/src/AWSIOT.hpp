
#ifndef __AWSIOT.H
#define __AWSIOT.H

#include "5G-NB-IoT_MQTT.h"

// This is StarfieldClass2.crt
// Qualcomm's logic is the root CA must be the rootest one.
// But he ROOT CA provide by Amazon by default is the intermediate one.

//////*********************************************///////
/***												*****/
/*** 	REPLACE THE FOLLOWING SECURITY CERTIFICATES *****/
/*** 	AND KEYS WITH YOUR OWN FROM AWS IoT			*****/
/***												*****/
//////*********************************************///////

char aws_root_ca_pem[]= "-----BEGIN CERTIFICATE-----\n\
MIIEDzCCAvegAwIBAgIBADANBgkqhkiG9w0BAQUFADBoMQswCQYDVQQGEwJVUzElMCMGA1UEChMcU3RhcmZpZWxkIFRlY2hub2xvZ2llcywgSW5jLjEyMDAGA1UECxMp\n\
-----END CERTIFICATE-----\n";

// "The certificate for this thing"
char certificate_pem_crt[] = "-----BEGIN CERTIFICATE-----\n\
MIIDWTCCAkGgAwIBAgIUWermTFtqBipvIdo9fw0sqlQmiUEwDQYJKoZIhvcNAQELBQAwTTFLMEkGA1UECwxCQW1hem9uIFdlYiBTZXJ2aWNlcyBPPUFtYXpvbi5jb20g\n\
-----END CERTIFICATE-----\n";


// "The private key of the thing". The public key is not needed here
char private_pem_key[] = "-----BEGIN RSA PRIVATE KEY-----\n\
MIIEowIBAAKCAQEAtqUK+kXqFRykCFCj44CxQbbykKxsKlGmpxvDvkwjbZ0PRXbq5Ufd/3SQNRmutGt9gqJShtz9AGtSL7AvbtnT4Ab7izN81PUfFN8blwKn0AZCr98V\n\
nsfodqU1/jMSKuy477qsnneFRKiHTBymwlQ4dF46SnrSZQEl7lLA-----END RSA PRIVATE KEY-----\n";

// AWSIoT is the object of class _5G_NB_IoT_MQTT 
// DSerial USB serial
// APN name
// APIN login,
// APN password ,
// MQTT server FQDN, 
// MQTT port, number
// MQTT Client Id such as "BasibPubSub",
// MQTT topic name, 
// MQTT QoS  such as AT_MOST_ONCE, 
// MQTT index: The range is 0 ~ 5
// PDP index:  The range is 1 ~ 16
// SSL index:  The range is 0 ~ 5

//char *ModemIMEI  is an output contains the IMEI
bool InitModemMQTT(_5G_NB_IoT_MQTT  &AWSIoT, 
                   Stream &DSerial, 
                   char *APN,
                   char *LOGIN,
                   char *PASSWORD,
                   char *MQTTServer, 
                   unsigned int MQTTPort, 
                   char *MQTTClientId,
                   char *mqtt_topicName, 
                   Mqtt_Qos_t MQTT_QoS = AT_MOST_ONCE, 
                   unsigned int MQTTIndex = 3, 
                   unsigned int PDPIndex = 1, 
                   unsigned int SSLIndex = 2,
                   char *ModemIMEI = NULL)
{
  Mqtt_Version_t version = MQTT_V3;

  AWSIoT.InitModule();
  DSerial.println("\r\n InitModule() OK!");
  
  AWSIoT.SetDevCommandEcho(false);
  
  char inf[64];
  if (AWSIoT.GetDevInformation(inf))
  {
    DSerial.println(inf);
  }
  
  char imei_tmp[64];
  if (AWSIoT.GetDevIMEI(imei_tmp))
  {
    String s = String(imei_tmp);
    s.trim();
    s.toCharArray(ModemIMEI, 64);
    DSerial.println(ModemIMEI);
  }

  AWSIoT.DeleteFiles("*");
  
  char apn_error[64];
  while (!AWSIoT.InitAPN(PDPIndex, APN, LOGIN, PASSWORD, apn_error)) 
  {
    DSerial.println(apn_error);
  }
  DSerial.println(apn_error);
  
  char ssl_error[128];
  while (!AWSIoT.InitSSL(SSLIndex, aws_root_ca_pem, certificate_pem_crt, private_pem_key, ssl_error)) 
  {
    DSerial.println(ssl_error);
  }
  DSerial.println(ssl_error);
  
  DSerial.println("\r\nStart Config the MQTT Parameter!");
  while (!AWSIoT.SetMQTTConfigureParameters(MQTTIndex, PDPIndex, version, 150, SERVER_STORE_SUBSCRIPTIONS)) 
  {
    DSerial.println("\r\nConfig the MQTT Parameter Fail!");
    int e_code;
    if (AWSIoT.returnErrorCode(e_code)) 
    {
      DSerial.print("\r\nERROR CODE: ");
      DSerial.println(e_code);
      DSerial.println("Please check the documentation for error details.");
    }
  }
  DSerial.println("\r\nConfig the MQTT Parameter Success!");
  
  while (!AWSIoT.SetMQTTEnableSSL(MQTTIndex, SSLIndex, true)) 
  {
    DSerial.println("\r\SetMQTTEnableSSL the MQTT Parameter Fail!");
    int e_code;
    if (AWSIoT.returnErrorCode(e_code)) 
    {
      DSerial.print("\r\nERROR CODE: ");
      DSerial.println(e_code);
      DSerial.println("Please check the documentation for error details.");
    }
  }
  DSerial.println("\r\SetMQTTEnableSSL the MQTT Parameter Success!");

  /*while(!AWSIoT.ConfigDNSServer(PDPIndex,"208.67.222.222", "208.67.220.220"))
  {
    DSerial.println("\r\DNS Configuraiton failed!");  
  }*/
  
  while (AWSIoT.OpenMQTTNetwork(MQTTIndex, MQTTServer, MQTTPort) != 0) 
  {
    DSerial.println("\r\nSet the MQTT Service Address Fail!");
    int e_code;
    if (AWSIoT.returnErrorCode(e_code)) 
    {
      DSerial.print("\r\nERROR CODE: ");
      DSerial.println(e_code);
      DSerial.println("Please check the documentation for error details.");
    }
  }
  DSerial.println("\r\nSet the MQTT Service Address Success!");
  
  DSerial.println("\r\nConfigure Timeout!");
  while(!AWSIoT.SetMQTTMessageTimeout(MQTTIndex, 10, 5, 1))
  {
      DSerial.println("\r\nMQTT Timeout Fail!");
      int e_code;
      if (AWSIoT.returnErrorCode(e_code)) 
      {
        DSerial.print("\r\nERROR CODE: ");
        DSerial.println(e_code);
        DSerial.println("Please check the documentation for error details.");
      }
    }
  
  DSerial.println("\r\nStart Create a MQTT Client!");
  while (AWSIoT.CreateMQTTClient(MQTTIndex, MQTTClientId, "", "") != 0) 
  {
    DSerial.println("\r\nCreate a MQTT Client Fail!");
    int e_code;
    if (AWSIoT.returnErrorCode(e_code)) 
    {
      DSerial.print("\r\nERROR CODE: ");
      DSerial.println(e_code);
      DSerial.println("Please check the documentation for error details.");
    }
  }
  DSerial.println("\r\nCreate a MQTT Client Success!");
  
  DSerial.println("\r\nStart MQTT Subscribe Topic!");
  while (AWSIoT.MQTTSubscribeTopic(MQTTIndex, 1, mqtt_topicName, MQTT_QoS) != 0) 
  {
    DSerial.println("\r\nMQTT Subscribe Topic Fail!");
    int e_code;
    if (AWSIoT.returnErrorCode(e_code)) 
    {
      DSerial.print("\r\nERROR CODE: ");
      DSerial.println(e_code);
      DSerial.println("Please check the documentation for error details.");
    }
  }
  DSerial.println("\r\nMQTT Subscribe Topic Success!");

  return true;
}

#endif
